import toastr from 'toastr';

toastr.options.positionClass = 'toast-top-right';
toastr.options.preventDuplicates = true;

export default toastr;
